# Dynamically-Generated-Draggable-Textviews
These Textviews are dynamically created and are also draggable on the screen. It was originally created to jumbo word games. This was created in android studio java

# Draggable Textviews In Android Studio.
Check out the code.
